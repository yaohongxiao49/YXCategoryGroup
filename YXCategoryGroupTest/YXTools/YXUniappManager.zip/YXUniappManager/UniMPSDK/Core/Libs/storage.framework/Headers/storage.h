//
//  storage.h
//  storage
//
//  Created by DCloud on 2018/6/13.
//  Copyright © 2018年 DCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for storage.
FOUNDATION_EXPORT double storageVersionNumber;

//! Project version string for storage.
FOUNDATION_EXPORT const unsigned char storageVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <storage/PublicHeader.h>

#import <storage/StorageManager.h>
