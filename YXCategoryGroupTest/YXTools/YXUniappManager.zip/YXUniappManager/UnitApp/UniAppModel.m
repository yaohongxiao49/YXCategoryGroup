//
//  UniAppModel.m
//  MuchProj
//
//  Created by Augus on 2023/5/24.
//

#import "UniAppModel.h"

@implementation UniAppModel

+ (JSONKeyMapper *)keyMapper {
    
    //属性名作为key, 字典中的key名 作为 value
    return [[JSONKeyMapper alloc] initWithModelToJSONDictionary:@{@"boolHatchingToH5":@"forceH5", @"uniAppId":@"appId", @"uniAppDownUrl":@"fileUrl", @"uniAppVersion":@"versionInside"}];
}

+ (BOOL)propertyIsOptional:(NSString *)propertyName {
    
    return true;
}

@end
