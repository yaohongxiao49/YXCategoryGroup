//
//  UnitAppUseManager.m
//  MuchProj
//
//  Created by Augus on 2023/4/19.
//

#import "UnitAppUseManager.h"

@interface UnitAppUseManager ()

@property (nonatomic, strong) UniAppModel *model;

@end

@implementation UnitAppUseManager

#pragma mark - 单例
+ (UnitAppUseManager *)shareIncetance {

    static UnitAppUseManager *manager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{

        manager = [[UnitAppUseManager alloc] init];
    });
    return manager;
}

#pragma mark - 下载或打开小程序
- (void)downOrOpenUniappByType:(NSInteger)type {
    
    kYXWeakSelf
    
    _model = [[UnitAppUseManager shareIncetance].modelDic yxObjForKey:[NSString stringWithFormat:@"%ld", type]];
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(queue, ^{
       
        NSString *caches = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
        NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
        NSString *saveFile = [NSString stringWithFormat:@"%@/%@/%@.wgt", caches, [infoDic objectForKey:@"CFBundleDisplayName"], weakSelf.model.uniAppId];
        if ([[NSFileManager defaultManager] fileExistsAtPath:saveFile]) { //判断是否存在文件
            [self judgeBoolNeedDownToUpdate];
        }
        else {
            [self downLoadUniapp];
        }
    });
}

#pragma mark - 判断是否需要下载更新
- (void)judgeBoolNeedDownToUpdate {
    
    NSDictionary *dic = [DCUniMPSDKEngine getUniMPVersionInfoWithAppid:_model.uniAppId];
    NSString *name = [dic yxObjForKey:@"name"]; //1.0.0
    NSInteger code = [[dic yxObjForKey:@"code"] integerValue];
    NSInteger remoteCode = [_model.uniAppVersion integerValue];
    if (remoteCode > code) { //需要下载更新
        [self downLoadUniapp];
    }
    else { //直接部署小程序
        NSString *caches = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
        NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
        NSString *savePath = [NSString stringWithFormat:@"%@/%@/%@.wgt", caches, [infoDic objectForKey:@"CFBundleDisplayName"], _model.uniAppId];
        [self deploymentUniAppByBoolReload:NO savePath:savePath];
    }
}

#pragma mark - 下载Uni-app并部署
- (void)downLoadUniapp {
    
    kYXWeakSelf
    [[YXBigFileDownloadRequest sharedManager] startDownloadByFileUrl:_model.uniAppDownUrl];
    [[YXBigFileDownloadRequest sharedManager] setYxBigFileDownloadRequestProgressBlock:^(double progress) {

        NSLog(@"下载progress == %.2f", progress);
    }];
    [[YXBigFileDownloadRequest sharedManager] setYxBigFileDownloadRequestBlock:^(NSString * _Nonnull savePath, NSString * _Nonnull fileName) {

        NSString *endSavePath = [NSString stringWithFormat:@"%@", savePath];
        //部署小程序
        [weakSelf deploymentUniAppByBoolReload:YES savePath:endSavePath];
    }];
}

#pragma mark - 部署小程序
- (void)deploymentUniAppByBoolReload:(BOOL)boolReload savePath:(NSString *)savePath {
 
    kYXWeakSelf
    [[YXUniappManager shareIncetance] checkUniMPResource:_model.uniAppId savePath:savePath boolReload:boolReload finished:^(BOOL boolSuccess) {
        
        if (boolSuccess) { //部署成功
            [weakSelf judgeOpenUniAppByIdent:weakSelf.model.uniAppId pointPath:@""];
        }
        else { //部署失败
            
        }
    }];
    [[YXUniappManager shareIncetance] setUniMPMenuItems];
}

#pragma mark - 判断打开Uni-app
- (void)judgeOpenUniAppByIdent:(NSString *)ident pointPath:(NSString *)pointPath {
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [[YXUniappManager shareIncetance] openPreloadUniappByAppid:ident pointPath:pointPath];
    });
}

@end
