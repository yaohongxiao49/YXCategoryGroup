//
//  UniAppModel.h
//  MuchProj
//
//  Created by Augus on 2023/5/24.
//

#import "JSONModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface UniAppModel : JSONModel

/** 孵化是否跳转H5 */
@property (nonatomic, assign) BOOL boolHatchingToH5;
/** 小程序Id */
@property (nonatomic, copy) NSString *uniAppId;
/** 小程序下载地址 */
@property (nonatomic, copy) NSString *uniAppDownUrl;
/** 小程序版本 */
@property (nonatomic, copy) NSString *uniAppVersion;

@end

NS_ASSUME_NONNULL_END
