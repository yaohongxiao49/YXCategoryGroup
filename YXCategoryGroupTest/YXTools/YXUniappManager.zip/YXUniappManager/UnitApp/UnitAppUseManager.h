//
//  UnitAppUseManager.h
//  MuchProj
//
//  Created by Augus on 2023/4/19.
//

#import <Foundation/Foundation.h>
#import "YXUniappManager.h"
#import "UniAppModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface UnitAppUseManager : NSObject

/** 单例 */
+ (UnitAppUseManager *)shareIncetance;

/** 模型 */
@property (nonatomic, strong) NSMutableDictionary *modelDic;

/**
 * 下载或打开小程序
 * @prama type 0：孵化
 */
- (void)downOrOpenUniappByType:(NSInteger)type;
/**
 * 判断打开Uni-app
 * @param ident 小程序id
 * @param pointPath 指定打开的地址
 */
- (void)judgeOpenUniAppByIdent:(NSString *)ident
                     pointPath:(NSString *)pointPath;

@end

NS_ASSUME_NONNULL_END
