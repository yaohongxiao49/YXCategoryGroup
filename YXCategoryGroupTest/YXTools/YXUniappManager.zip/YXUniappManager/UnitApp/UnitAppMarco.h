//
//  UnitAppMarco.h
//  MuchProj
//
//  Created by Augus on 2023/4/19.
//

#ifndef UnitAppMarco_h
#define UnitAppMarco_h

#pragma mark - path
/** 孵化-龙蛋 */
#define kUniHachingGiantPath @"pages/incubation/incubationHomeT"
/** 孵化-龙魂 */
#define kUniHachingMagicPath @"pages/incubation/incubationHome2T"
/** 孵化-龙精 */
#define kUniHachingHolyPath @"pages/incubation/incubationHome3T"

#endif /* UnitAppMarco_h */
