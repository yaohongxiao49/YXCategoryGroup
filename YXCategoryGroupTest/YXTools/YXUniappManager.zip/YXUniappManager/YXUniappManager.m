//
//  YXUniappManager.m
//  MuchProj
//
//  Created by Augus on 2023/1/28.
//

#import "YXUniappManager.h"

@interface YXUniappManager () <DCUniMPSDKEngineDelegate>

@end

@implementation YXUniappManager

+ (YXUniappManager *)shareIncetance {

    static YXUniappManager *manager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{

        manager = [[YXUniappManager alloc] init];
    });
    return manager;
}

#pragma mark - 检查运行目录是否存在应用资源，不存在将应用资源部署到运行目录
- (void)checkUniMPResource:(NSString *)appid savePath:(NSString *)savePath boolReload:(BOOL)boolReload finished:(YXUniappFinishBlock)finished {

    NSString *appResourcePath = savePath.yxHasValue ? savePath : [[NSBundle mainBundle] pathForResource:appid ofType:@"wgt"];
    if (![DCUniMPSDKEngine isExistsUniMP:appid] || boolReload) {
        //读取导入到工程中的wgt应用资源
        if (!appResourcePath) {
            NSLog(@"资源路径不正确，请检查");
            if (finished) {
                finished(NO);
            }
            return;
        }
        //将应用资源部署到运行路径中
        NSError *error;
        if ([DCUniMPSDKEngine installUniMPResourceWithAppid:appid resourceFilePath:appResourcePath password:nil error:&error]) {
            NSLog(@"小程序 %@ 应用资源文件部署成功，版本信息：%@", appid, [DCUniMPSDKEngine getUniMPVersionInfoWithAppid:appid]);
            if (finished) {
                finished(YES);
            }
        }
        else {
            NSLog(@"小程序 %@ 应用资源部署失败： %@", appid, error);
            if (finished) {
                finished(NO);
            }
        }
    }
    else {
        NSLog(@"已存在小程序 %@ 应用资源，版本信息：%@", appid, [DCUniMPSDKEngine getUniMPVersionInfoWithAppid:appid]);
        if (finished) {
            finished(YES);
        }
    }
}

#pragma mark - 配置胶囊按钮菜单 ActionSheet 全局项（点击胶囊按钮 ··· ActionSheet弹窗中的项）
- (void)setUniMPMenuItems {
    
    DCUniMPMenuActionSheetItem *item1 = [[DCUniMPMenuActionSheetItem alloc] initWithTitle:@"将小程序隐藏到后台" identifier:@"enterBackground"];
    DCUniMPMenuActionSheetItem *item2 = [[DCUniMPMenuActionSheetItem alloc] initWithTitle:@"关闭小程序" identifier:@"closeUniMP"];
    //添加到全局配置
    [DCUniMPSDKEngine setDefaultMenuItems:@[item1, item2]];
    [DCUniMPSDKEngine setAutoControlNavigationBar:NO];
    [DCUniMPSDKEngine setCapsuleButtonHidden:NO];
    
    //设置 delegate
    [DCUniMPSDKEngine setDelegate:self];
}

#pragma mark - 直接打开应用
- (void)openDirectUniappByAppid:(NSString *)appid pointPath:(NSString *)pointPath openBlock:(void(^)(BOOL success))openBlock {
    
    //获取配置信息
    DCUniMPConfiguration *configuration = [[DCUniMPConfiguration alloc] init];
//    //配置启动小程序时传递的数据（目标小程序可在 App.onLaunch，App.onShow 中获取到启动时传递的数据）
//    configuration.extraData = @{@"launchInfo":@"Hello UniMP"};
    //配置小程序启动后直接打开的页面路径 例：@"pages/component/view/view?action=redirect&password=123456"
    if (pointPath.yxHasValue) configuration.path = pointPath;
    
    //开启后台运行
    configuration.enableBackground = YES;
    //设置打开方式
    configuration.openMode = DCUniMPOpenModePush;
    //启用侧滑手势关闭小程序
    configuration.enableGestureClose = YES;
    
    //打开小程序
    __weak __typeof(self) weakSelf = self;
    [DCUniMPSDKEngine openUniMP:appid configuration:configuration completed:^(DCUniMPInstance * _Nullable uniMPInstance, NSError * _Nullable error) {
        
        if (uniMPInstance) {
            weakSelf.uniMPInstance = uniMPInstance;
            openBlock(YES);
        }
        else {
            NSLog(@"打开小程序出错：%@", error);
            openBlock(NO);
        }
    }];
}

#pragma mark - 预加载打开应用
- (void)openPreloadUniappByAppid:(NSString *)appid pointPath:(NSString *)pointPath {
    
    //获取配置信息
    DCUniMPConfiguration *configuration = [[DCUniMPConfiguration alloc] init];
    if (pointPath.yxHasValue) configuration.path = pointPath;
    
    //开启后台运行
    configuration.enableBackground = YES;
    //设置打开方式
    configuration.openMode = DCUniMPOpenModePush;
    //启用侧滑手势关闭小程序
    configuration.enableGestureClose = YES;
//    //隐藏开启动画
//    configuration.showAnimated = NO;

    //预加载小程序
    __weak __typeof(self) weakSelf = self;
    [DCUniMPSDKEngine preloadUniMP:appid configuration:configuration completed:^(DCUniMPInstance * _Nullable uniMPInstance, NSError * _Nullable error) {
        
        if (uniMPInstance) {
            weakSelf.uniMPInstance = uniMPInstance;
            //预加载后打开小程序
            [uniMPInstance showWithCompletion:^(BOOL success, NSError * _Nullable error) {
              
                if (error) {
                    NSLog(@"show 小程序失败：%@", error);
                }
            }];
        }
        else {
            NSLog(@"预加载小程序出错：%@", error);
        }
    }];
}

#pragma mark - 小程序隐藏至后台
- (void)hiddenUniToBackgroundMethod {
    
    __weak __typeof(self) weakSelf = self;
    [self.uniMPInstance hideWithCompletion:^(BOOL success, NSError * _Nullable error) {

        if (success) {
            NSLog(@"小程序 %@ 进入后台", weakSelf.uniMPInstance.appid);
        }
        else {
            NSLog(@"hide小程序出错：%@", error);
        }
    }];
}

#pragma mark - 小程序关闭
- (void)clossUniMethod {
    
    __weak __typeof(self) weakSelf = self;
    [self.uniMPInstance closeWithCompletion:^(BOOL success, NSError * _Nullable error) {

        if (success) {
            NSLog(@"小程序closed %@", weakSelf.uniMPInstance.appid);
        }
        else {
            NSLog(@"close小程序出错：%@",error);
        }
    }];
}

#pragma mark - 跳转原生开发页面（dic 返回的参数）
- (void)pushToAppControllerByDic:(NSDictionary *)dic {
    
    //跳转类型
    NSInteger type = [[dic yxObjForKey:@"jumpType"] integerValue];
    NSString *jumpUrl = [dic yxObjForKey:@"jumpUrl"];
    
    [self hiddenUniToBackgroundMethod];
    switch (type) {
        case -1: //外链
            [[YXBasePushManager shareManager] pushToWithinUrl:jumpUrl];
            break;
        case 0: //内链
            [self goAppInternalLinks:jumpUrl];
            break;
        case 11: { //客服
            [[YXBasePushManager shareManager] pushToServiceVC:[AccountManager getCurrentShowVCByBoolTabBarVC:NO] boolNeedLogin:YES ident:[[AccountManager sharedManager].userId integerValue] preSendMessageArr:@[]];
            break;
        }
        default:
            break;
    }
}

#pragma mark - 跳内部浏览器
- (void)goAppInternalLinks:(NSString *)url {
    
    BOOL boolAnimation = YES;
    if ([url containsString:@"incubation/incubationHome"]) boolAnimation = NO;
    [[YXBasePushManager shareManager] pushToWebVCByBaseVC:[AccountManager getCurrentShowVCByBoolTabBarVC:NO] url:url parameter:nil boolShowAnimation:boolAnimation];
}

#pragma mark - 去登录
- (void)goLogin {
    
    if ([[YXToolAppBaseMessage instanceManager] boolToSimple] && [AccountManager sharedManager].isLogin == NO) {
        [YXNetworkUse yxPostTokenHTTPByPhone:@"18111566238" code:@"1" inviteCode:@"" showText:@"" isShowSuccess:NO isShowError:NO finishBlock:^(id  _Nullable result, BOOL boolSuccess) {
           
            if (boolSuccess) {
                AccountManager *account = [AccountManager sharedManager];
                account.isLogin = YES;
                [account updateCacheAccountInfo];
                
                //友盟推送
                if (account.userId.yxHasValue) [UMessage setAlias:account.userId type:@"userId" response:^(id responseObject, NSError *error) {}];
                [account updateLoginAccountInfo:result];
                [account updateAccountInfo:^{
                    
                }];
            }
            else {
                [AccountManager goLogin];
            }
        }];
    }
    else {
        [AccountManager goLogin];
    }
}

#pragma mark - <DCUniMPSDKEngineDelegate>
#pragma mark - 胶囊按钮‘x’关闭按钮点击回调
- (void)closeButtonClicked:(NSString *)appid {

    NSLog(@"点击了小程序 %@ 的关闭按钮", appid);
}

#pragma mark - DCUniMPMenuActionSheetItem 点击触发回调方法
- (void)defaultMenuItemClicked:(NSString *)appid identifier:(NSString *)identifier {

    NSLog(@"标识为 %@ 的item被点击了", identifier);

    if ([identifier isEqualToString:@"enterBackground"]) { //将小程序隐藏到后台
        [self hiddenUniToBackgroundMethod];
    }
    else if ([identifier isEqualToString:@"closeUniMP"]) { //关闭小程序
        [self clossUniMethod];
    }
    else if ([identifier isEqualToString:@"SendUniMPEvent"]) { //向小程序发送消息
        [self.uniMPInstance sendUniMPEvent:@"NativeEvent" data:@{@"msg":@"native message"}];
    }
}

#pragma mark - 返回打开小程序时的自定义闪屏视图
- (UIView *)splashViewForApp:(NSString *)appid {

    YXNullPromptView *loadingView = [[YXNullPromptView alloc] initWithFrame:CGRectMake(0, kYXStBarNaBarHeight, kYXWidth, kYXHeight - kYXStBarNaBarHeight)];
    loadingView.type = YXNullPromptViewTypeLoading;
    loadingView.backgroundColor = kYXBackgroundColor;
    return loadingView;
}

#pragma mark - 小程序关闭回调方法
- (void)uniMPOnClose:(NSString *)appid {

    NSLog(@"小程序 %@ 被关闭了", appid);
    self.uniMPInstance = nil;
}

#pragma mark - 小程序向原生发送事件回调方法
- (void)onUniMPEventReceive:(NSString *)appid event:(NSString *)event data:(id)data callback:(DCUniMPKeepAliveCallback)callback {

    NSLog(@"Receive UniMP:%@ event:%@ data:%@", appid, event, data);

    if ([event isEqualToString:@"appGetToken"]) { //发送token
        NSDictionary *accountInfo = @{@"refresh_token":[AccountManager sharedManager].isLogin ? [AccountManager sharedManager].refreshUserToken : @"", @"access_token":[AccountManager sharedManager].isLogin ? [AccountManager sharedManager].userToken : @"", @"build_type":kServerDebug == 0 ? @"release" : @"pre"};
        if (callback) {
            callback(accountInfo, NO);
        }
    }
    else if ([event isEqualToString:@"appJumpPage"]) { //跳转事件
        [self pushToAppControllerByDic:data];
    }
    else if ([event isEqualToString:@"appTokenInvalid"]) { //跳转登录
        [self goLogin];
    }
}

@end
