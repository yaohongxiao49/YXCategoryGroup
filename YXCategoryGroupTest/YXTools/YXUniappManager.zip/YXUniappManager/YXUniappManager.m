//
//  YXUniappManager.m
//  MuchProj
//
//  Created by Augus on 2023/1/28.
//

#import "YXUniappManager.h"

@interface YXUniappManager () <DCUniMPSDKEngineDelegate>

@end

@implementation YXUniappManager

+ (YXUniappManager *)shareIncetance {

    static YXUniappManager *manager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{

        manager = [[YXUniappManager alloc] init];
    });
    return manager;
}

#pragma mark - 检查运行目录是否存在应用资源，不存在将应用资源部署到运行目录
- (void)checkUniMPResource:(NSString *)appid {

#warning 注意：isExistsUniMP: 方法判断的仅是运行路径中是否有对应的应用资源，宿主还需要做好内置wgt版本的管理，如果更新了内置的wgt也应该执行 installUniMPResourceWithAppid 方法应用最新的资源
    if (![DCUniMPSDKEngine isExistsUniMP:appid]) {
        //读取导入到工程中的wgt应用资源
        NSString *appResourcePath = [[NSBundle mainBundle] pathForResource:appid ofType:@"wgt"];
        if (!appResourcePath) {
            NSLog(@"资源路径不正确，请检查");
            return;
        }
        //将应用资源部署到运行路径中
        NSError *error;
        if ([DCUniMPSDKEngine installUniMPResourceWithAppid:appid resourceFilePath:appResourcePath password:nil error:&error]) {
            NSLog(@"小程序 %@ 应用资源文件部署成功，版本信息：%@", appid, [DCUniMPSDKEngine getUniMPVersionInfoWithAppid:appid]);
        }
        else {
            NSLog(@"小程序 %@ 应用资源部署失败： %@", appid, error);
        }
    }
    else {
        NSLog(@"已存在小程序 %@ 应用资源，版本信息：%@", appid, [DCUniMPSDKEngine getUniMPVersionInfoWithAppid:appid]);
    }
}

#pragma mark - 配置胶囊按钮菜单 ActionSheet 全局项（点击胶囊按钮 ··· ActionSheet弹窗中的项）
- (void)setUniMPMenuItems {
    
    DCUniMPMenuActionSheetItem *item1 = [[DCUniMPMenuActionSheetItem alloc] initWithTitle:@"将小程序隐藏到后台" identifier:@"enterBackground"];
    DCUniMPMenuActionSheetItem *item2 = [[DCUniMPMenuActionSheetItem alloc] initWithTitle:@"关闭小程序" identifier:@"closeUniMP"];
    DCUniMPMenuActionSheetItem *item3 = [[DCUniMPMenuActionSheetItem alloc] initWithTitle:@"SendUniMPEvent" identifier:@"SendUniMPEvent"];
    //添加到全局配置
    [DCUniMPSDKEngine setDefaultMenuItems:@[item1, item2, item3]];
    [DCUniMPSDKEngine setAutoControlNavigationBar:NO];
    
    //设置 delegate
    [DCUniMPSDKEngine setDelegate:self];
}

#pragma mark - 直接打开应用
- (void)openDirectUniappByAppid:(NSString *)appid {
    
    //获取配置信息
    DCUniMPConfiguration *configuration = [[DCUniMPConfiguration alloc] init];
    //配置启动小程序时传递的数据（目标小程序可在 App.onLaunch，App.onShow 中获取到启动时传递的数据）
    configuration.extraData = @{@"launchInfo":@"Hello UniMP"};
    //配置小程序启动后直接打开的页面路径 例：@"pages/component/view/view?action=redirect&password=123456"
//    configuration.path = @"pages/component/view/view?action=redirect&password=123456";
    
    //开启后台运行
    configuration.enableBackground = YES;
    //设置打开方式
    configuration.openMode = DCUniMPOpenModePush;
    //启用侧滑手势关闭小程序
    configuration.enableGestureClose = YES;
    
    //打开小程序
    __weak __typeof(self) weakSelf = self;
    [DCUniMPSDKEngine openUniMP:appid configuration:configuration completed:^(DCUniMPInstance * _Nullable uniMPInstance, NSError * _Nullable error) {
        
        if (uniMPInstance) {
            weakSelf.uniMPInstance = uniMPInstance;
        }
        else {
            NSLog(@"打开小程序出错：%@", error);
        }
    }];
}

#pragma mark - 预加载打开应用
- (void)openPreloadUniappByAppid:(NSString *)appid {
    
    //获取配置信息
    DCUniMPConfiguration *configuration = [[DCUniMPConfiguration alloc] init];
    //开启后台运行
    configuration.enableBackground = YES;
    //设置打开方式
    configuration.openMode = DCUniMPOpenModePush;
    //启用侧滑手势关闭小程序
    configuration.enableGestureClose = YES;

    //预加载小程序
    __weak __typeof(self) weakSelf = self;
    [DCUniMPSDKEngine preloadUniMP:appid configuration:configuration completed:^(DCUniMPInstance * _Nullable uniMPInstance, NSError * _Nullable error) {
        
        if (uniMPInstance) {
            weakSelf.uniMPInstance = uniMPInstance;
            //预加载后打开小程序
            [uniMPInstance showWithCompletion:^(BOOL success, NSError * _Nullable error) {
              
                if (error) {
                    NSLog(@"show 小程序失败：%@", error);
                }
            }];
        }
        else {
            NSLog(@"预加载小程序出错：%@", error);
        }
    }];
}

#pragma mark - <DCUniMPSDKEngineDelegate>
#pragma mark - 胶囊按钮‘x’关闭按钮点击回调
- (void)closeButtonClicked:(NSString *)appid {

    NSLog(@"点击了小程序 %@ 的关闭按钮", appid);
}

#pragma mark - DCUniMPMenuActionSheetItem 点击触发回调方法
- (void)defaultMenuItemClicked:(NSString *)appid identifier:(NSString *)identifier {

    NSLog(@"标识为 %@ 的item被点击了", identifier);

    if ([identifier isEqualToString:@"enterBackground"]) { //将小程序隐藏到后台
        __weak __typeof(self) weakSelf = self;
        [self.uniMPInstance hideWithCompletion:^(BOOL success, NSError * _Nullable error) {

            if (success) {
                NSLog(@"小程序 %@ 进入后台", weakSelf.uniMPInstance.appid);
            }
            else {
                NSLog(@"hide小程序出错：%@", error);
            }
        }];
    }
    else if ([identifier isEqualToString:@"closeUniMP"]) { //关闭小程序
        [self.uniMPInstance closeWithCompletion:^(BOOL success, NSError * _Nullable error) {

            if (success) {
                NSLog(@"小程序closed");
            }
            else {
                NSLog(@"close小程序出错：%@",error);
            }
        }];
    }
    else if ([identifier isEqualToString:@"SendUniMPEvent"]) { //向小程序发送消息
        [self.uniMPInstance sendUniMPEvent:@"NativeEvent" data:@{@"msg":@"native message"}];
    }
}

#pragma mark - 返回打开小程序时的自定义闪屏视图
- (UIView *)splashViewForApp:(NSString *)appid {

    UIView *splashView = [UIView new];
    return splashView;
}

#pragma mark - 小程序关闭回调方法
- (void)uniMPOnClose:(NSString *)appid {

    NSLog(@"小程序 %@ 被关闭了", appid);
    self.uniMPInstance = nil;
}

#pragma mark - 小程序向原生发送事件回调方法
- (void)onUniMPEventReceive:(NSString *)appid event:(NSString *)event data:(id)data callback:(DCUniMPKeepAliveCallback)callback {

    NSLog(@"Receive UniMP:%@ event:%@ data:%@", appid, event, data);

    //回传数据给小程序
    //DCUniMPKeepAliveCallback 用法请查看定义说明
    if (callback) {
        callback(@"native callback message", NO);
    }
}

@end
