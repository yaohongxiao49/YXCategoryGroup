//
//  YXUniappManager.h
//  MuchProj
//
//  Created by Augus on 2023/1/28.
//

#import <Foundation/Foundation.h>
#import "DCUniMP.h"
#import "WeexSDK.h"

NS_ASSUME_NONNULL_BEGIN

/** 结果返回block */
typedef void (^YXUniappFinishBlock) (BOOL boolSuccess);

@interface YXUniappManager : NSObject

@property (nonatomic, weak) DCUniMPInstance *uniMPInstance; /**< 保存当前打开的小程序应用的引用 注意：请使用 weak 修辞，否则应在关闭小程序时置为 nil */

+ (YXUniappManager *)shareIncetance;

/** 检查运行目录是否存在应用资源，不存在将应用资源部署到运行目录 */
- (void)checkUniMPResource:(NSString *)appid savePath:(NSString *)savePath boolReload:(BOOL)boolReload finished:(YXUniappFinishBlock)finished;

/** 直接打开应用 */
- (void)openDirectUniappByAppid:(NSString *)appid pointPath:(NSString *)pointPath openBlock:(void(^)(BOOL success))openBlock;

/** 预加载打开应用 */
- (void)openPreloadUniappByAppid:(NSString *)appid pointPath:(NSString *)pointPath;

/** 配置胶囊按钮菜单 ActionSheet 全局项（点击胶囊按钮 ··· ActionSheet弹窗中的项）*/
- (void)setUniMPMenuItems;

@end

NS_ASSUME_NONNULL_END
